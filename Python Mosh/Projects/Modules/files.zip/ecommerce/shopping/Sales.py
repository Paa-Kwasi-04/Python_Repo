from ecommerce.customer import contact  # This is absolute import

# OR
from ..customer import contact  # Relative import statement


def calc_tax():
    pass


def calc_shipping():
    pass

if __name__ == '__main__':
    __main__()