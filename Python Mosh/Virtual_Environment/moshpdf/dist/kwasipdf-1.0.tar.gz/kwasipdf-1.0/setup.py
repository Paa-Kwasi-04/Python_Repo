import setuptools

setuptools.setup(
    name='kwasipdf',
    version=1.0,
    long_description="",
    packages=setuptools.find_packages(['tests', 'data'])
)
